var searchData=
[
  ['approx_0',['approx',['../struct_catch_1_1_matchers_1_1_vector_1_1_approx_matcher.html#a0da9e77e66822ed7fd0164fc42420fa5',1,'Catch::Matchers::Vector::ApproxMatcher']]],
  ['assertions_1',['assertions',['../struct_catch_1_1_totals.html#a885ded66df752147b30c3d45aa602ec9',1,'Catch::Totals']]]
];
