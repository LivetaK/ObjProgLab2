var searchData=
[
  ['reference_0',['reference',['../class_vector.html#a2469703660944eaf3701646d44db8485',1,'Vector']]]
];
