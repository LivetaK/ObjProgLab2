var searchData=
[
  ['užpildymo_20greitis_0',['Užpildymo greitis',['../md__r_e_a_d_m_e.html#autotoc_md0',1,'']]]
];
