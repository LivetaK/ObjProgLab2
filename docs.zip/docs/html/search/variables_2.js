var searchData=
[
  ['description_0',['description',['../struct_catch_1_1_section_info.html#a0052060219a6de74bb7ade34d4163a4e',1,'Catch::SectionInfo::description'],['../struct_catch_1_1_test_case_info.html#a37fe2db9425bc45f6a33893eac31198e',1,'Catch::TestCaseInfo::description']]],
  ['durationinseconds_1',['durationInSeconds',['../struct_catch_1_1_section_end_info.html#a7c262f2dab9cff166b8eca620c47eea5',1,'Catch::SectionEndInfo']]]
];
