var searchData=
[
  ['var_0',['var',['../classzmogus.html#a5feb8368e51a56118d057d6f7a1476b2',1,'zmogus']]]
];
