var searchData=
[
  ['specialproperties_0',['SpecialProperties',['../struct_catch_1_1_test_case_info.html#a39b232f74b4a7a6f2183b96759027eac',1,'Catch::TestCaseInfo']]]
];
