var searchData=
[
  ['threwexception_0',['ThrewException',['../struct_catch_1_1_result_was.html#a624e1ee3661fcf6094ceef1f654601efa3bb56296483947280cf7fa1ad074ab45',1,'Catch::ResultWas']]],
  ['throws_1',['Throws',['../struct_catch_1_1_test_case_info.html#a39b232f74b4a7a6f2183b96759027eaca4704adf89ed7f7ad653d08f99813a974',1,'Catch::TestCaseInfo']]]
];
