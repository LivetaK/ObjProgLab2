var searchData=
[
  ['funkcijos_2eh_0',['funkcijos.h',['../funkcijos_8h.html',1,'']]]
];
