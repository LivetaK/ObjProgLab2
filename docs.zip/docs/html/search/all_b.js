var searchData=
[
  ['readme_0',['README',['../md__r_e_a_d_m_e.html',1,'']]],
  ['reference_1',['reference',['../class_vector.html#a2469703660944eaf3701646d44db8485',1,'Vector']]],
  ['reserve_2',['Reserve',['../class_vector.html#abf481e2e77200776e8f7fdf6cc2b1470',1,'Vector']]],
  ['resize_3',['Resize',['../class_vector.html#a8f4e123e7adc35fe84ceae1c51567c1e',1,'Vector']]],
  ['rikiavimas_4',['rikiavimas',['../funkcijos_8h.html#a5a7edd4ea3a055c50434ba0d65a06fcf',1,'funkcijos.cpp']]],
  ['rikiavimoklausimas_5',['rikiavimoklausimas',['../funkcijos_8h.html#a67fce8ea0770d14ed6cc024d0428440f',1,'funkcijos.cpp']]]
];
