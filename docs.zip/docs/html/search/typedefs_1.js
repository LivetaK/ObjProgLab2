var searchData=
[
  ['exceptiontranslatefunction_0',['exceptionTranslateFunction',['../namespace_catch.html#a7f2ab9adc3729f9c197f43e5cfcd4b40',1,'Catch']]],
  ['exceptiontranslators_1',['ExceptionTranslators',['../namespace_catch.html#a49b7a6b4679e1b57f1646f0ebda713b6',1,'Catch']]]
];
