var searchData=
[
  ['testavimorezultatai_0',['testavimoRezultatai',['../funkcijos_8h.html#aa9419267e510bb1f5d6381d328c29850',1,'funkcijos.cpp']]],
  ['treciasp_1',['treciasP',['../funkcijos_8h.html#abfbb40470445383820ddc05eb349d63d',1,'funkcijos.cpp']]],
  ['trukmesskaiciavimas_2',['trukmesSkaiciavimas',['../funkcijos_8h.html#a8665d13dd4ea1bee6d38c6c20ed456a2',1,'funkcijos.cpp']]]
];
