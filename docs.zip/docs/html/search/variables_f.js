var searchData=
[
  ['value_0',['value',['../class_catch_1_1_detail_1_1_is_stream_insertable.html#a42818b09ae5851126a70ee263769e309',1,'Catch::Detail::IsStreamInsertable']]],
  ['var_1',['var',['../classzmogus.html#a5feb8368e51a56118d057d6f7a1476b2',1,'zmogus']]]
];
