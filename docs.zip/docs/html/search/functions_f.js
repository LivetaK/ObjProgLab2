var searchData=
[
  ['zmogus_0',['zmogus',['../classzmogus.html#a903c961f64b1adcc7bab25cba2814811',1,'zmogus::zmogus()=default'],['../classzmogus.html#ad7bbc6714466586dbd8f119bd8e61d6f',1,'zmogus::zmogus(const zmogus &amp;laikStud)'],['../classzmogus.html#a3f175f7bb718dbaccfb4fadfc6d7246c',1,'zmogus::zmogus(zmogus &amp;&amp;laikStud) noexcept']]]
];
