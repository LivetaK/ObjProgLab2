var searchData=
[
  ['oftype_0',['OfType',['../struct_catch_1_1_result_was.html#a624e1ee3661fcf6094ceef1f654601ef',1,'Catch::ResultWas']]],
  ['ornot_1',['OrNot',['../struct_catch_1_1_show_durations.html#a82fa0174554187220c1eda175f122ee1',1,'Catch::ShowDurations']]]
];
