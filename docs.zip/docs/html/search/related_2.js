var searchData=
[
  ['getcurrentmutablecontext_0',['getCurrentMutableContext',['../struct_catch_1_1_i_mutable_context.html#ad22507c2e4bc58f80a205db9756b8e29',1,'Catch::IMutableContext']]]
];
