var searchData=
[
  ['iconfigptr_0',['IConfigPtr',['../namespace_catch.html#a961f6f5f07e265684c220a8ae014d7d6',1,'Catch']]],
  ['ireporterfactoryptr_1',['IReporterFactoryPtr',['../namespace_catch.html#a4e6617700df10519be17cc0e62ab427e',1,'Catch']]]
];
