var searchData=
[
  ['geteg_0',['geteg',['../classmok.html#acf38d3f2063d7a7b896795bc4cb9ef91',1,'mok']]],
  ['getgal_5fmed_1',['getgal_med',['../classmok.html#a87b64934bdafe1a92f08263e839c0705',1,'mok']]],
  ['getgal_5fvid_2',['getgal_vid',['../classmok.html#a688d43a2b75b6e75dc1298238f21e79b',1,'mok']]],
  ['getnd_3',['getnd',['../classmok.html#ac623138deb040c8ad102f2ba4e3518b7',1,'mok']]],
  ['getpav_4',['getpav',['../classzmogus.html#afe54f1a852f3546c602421c1daa9f6ab',1,'zmogus::getpav()'],['../classmok.html#a95de1c99979296658ff234449dd4d2e5',1,'mok::getpav()']]],
  ['getvar_5',['getvar',['../classzmogus.html#aaf0840f345539adc6d3f01f97dfa4237',1,'zmogus::getvar()'],['../classmok.html#a9bae04251d768fe28dc6f750388394c2',1,'mok::getvar()']]],
  ['greitis_6',['Užpildymo greitis',['../md__r_e_a_d_m_e.html#autotoc_md0',1,'']]]
];
